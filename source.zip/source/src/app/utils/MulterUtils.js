const multer = require('multer')

// SET STORAGE
File.prototype.base64 = function () {
    var img = fs.readFileSync(image);
    var encode_image = img.toString('base64');
    // Define a JSONobject for the image attributes for saving to database

    var finalImg = {
        contentType: req.file.mimetype,
        image: new Buffer(encode_image, 'base64')
    };

    return finalImg
}

module.exports = File;