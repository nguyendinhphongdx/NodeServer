const ClassModel = require("../../Models/ClassModel");
const jsonInstance = require("../../utils/JsonUtils");
const responeInstance = require("../../utils/ResponeUtils");
exports.pushNotif =(_class,start,end,message)=>{
    ClassModel
}